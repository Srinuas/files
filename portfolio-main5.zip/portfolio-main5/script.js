// script.js

window.addEventListener("scroll", function() {
    const navbar = document.getElementById("navbar");
    const scrollUpBtn = document.getElementById("scrollUp");
    
    if (window.scrollY > 50) {
        navbar.style.background = "rgba(10, 10, 15, 0.95)";
        navbar.style.padding = "14px 0";
        navbar.style.boxShadow = "0 4px 30px rgba(0,0,0,0.6)";
        navbar.style.backdropFilter = "blur(10px)";
    } else {
        navbar.style.background = "transparent";
        navbar.style.padding = "20px 0";
        navbar.style.boxShadow = "none";
        navbar.style.backdropFilter = "none";
    }

    if (window.scrollY > 300) {
        scrollUpBtn.classList.add("show");
    } else {
        scrollUpBtn.classList.remove("show");
    }
});

const typedTextSpan = document.querySelector(".typed-text");
const textArray = ["AWS DevOps Engineer", "Site Reliability Engineer", "Cloud Infrastructure Engineer", "Platform Engineer"];
let textArrayIndex = 0, charIndex = 0;

function type() {
    if (typedTextSpan && charIndex < textArray[textArrayIndex].length) {
        if (charIndex === 0 && typedTextSpan.innerHTML === "&nbsp;") typedTextSpan.textContent = "";
        typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
        charIndex++;
        setTimeout(type, 80);
    } else if (typedTextSpan) {
        setTimeout(erase, 3000);
    }
}

function erase() {
    if (typedTextSpan && charIndex > 0) {
        typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(erase, 40);
    } else if (typedTextSpan) {
        typedTextSpan.innerHTML = "&nbsp;";
        textArrayIndex++;
        if (textArrayIndex >= textArray.length) textArrayIndex = 0;
        setTimeout(type, 380);
    }
}

document.addEventListener("DOMContentLoaded", function() {
    if (typedTextSpan && textArray.length) setTimeout(type, 800);
});

const mobileMenu = document.getElementById("mobile-menu");
const navLinks = document.querySelector(".nav-links");
const menuIcon = mobileMenu ? mobileMenu.querySelector("i") : null;

if (mobileMenu && navLinks) {
    mobileMenu.addEventListener("click", (e) => {
        e.stopPropagation();
        navLinks.classList.toggle("active");
        menuIcon.classList.toggle("fa-bars");
        menuIcon.classList.toggle("fa-xmark");
    });
    document.querySelectorAll(".nav-links a").forEach(link => {
        link.addEventListener("click", () => {
            navLinks.classList.remove("active");
            if (menuIcon) {
                menuIcon.classList.add("fa-bars");
                menuIcon.classList.remove("fa-xmark");
            }
        });
    });
}

function openSecretConsole() {
    const modal = document.getElementById('secretConsoleModal');
    const pinAuth = document.getElementById('pinAuthSection');
    const filesConsole = document.getElementById('filesConsoleSection');
    const pinInput = document.getElementById('secretPinInput');
    const pinError = document.getElementById('secretPinError');

    if (!modal) return;
    modal.style.display = 'flex';
    if (pinAuth) pinAuth.style.display = 'block';
    if (filesConsole) filesConsole.style.display = 'none';
    if (pinError) pinError.style.display = 'none';
    if (pinInput) {
        pinInput.value = '';
        setTimeout(() => pinInput.focus(), 100);
    }
}

function closeSecretConsole() {
    const modal = document.getElementById('secretConsoleModal');
    if (modal) modal.style.display = 'none';
}

function checkAutoVerifyPin(event) {
    const pinInput = document.getElementById('secretPinInput').value;
    if (pinInput === '0000' || pinInput.length === 4) {
        verifySecretPin();
    }
}

function verifySecretPin() {
    const pinInput = document.getElementById('secretPinInput').value;
    const pinError = document.getElementById('secretPinError');
    const pinWrapper = document.getElementById('pinInputWrapper');

    if (pinInput === '0000') {
        if (pinError) pinError.style.display = 'none';
        document.getElementById('pinAuthSection').style.display = 'none';
        document.getElementById('filesConsoleSection').style.display = 'block';
        loadFilesRepositoryTree();
    } else {
        if (pinError) pinError.style.display = 'block';
        if (pinWrapper) {
            pinWrapper.classList.add('shake-error');
            setTimeout(() => pinWrapper.classList.remove('shake-error'), 500);
        }
    }
}

let pendingFileToUpload = null;

async function loadFilesRepositoryTree() {
    const fileContainer = document.getElementById('githubFileList');
    if (!fileContainer) return;
    fileContainer.innerHTML = '<p class="console-log"><i class="fa-solid fa-spinner fa-spin"></i> Fetching files from public "files" repository...</p>';

    const owner = 'Srinuas';
    const repo = 'files';
    const branch = 'main';

    try {
        const response = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/trees/${branch}?recursive=1`);
        if (!response.ok) throw new Error('Repository tree fetch failed');
        
        const data = await response.json();
        let files = [];
        data.tree.forEach(item => {
            if (item.type === 'blob') {
                const fileName = item.path;
                const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${fileName}`;
                files.push({ name: fileName, url: rawUrl, sha: item.sha });
            }
        });

        renderFileList(files);
    } catch (error) {
        console.error('Error fetching files repo:', error);
        fileContainer.innerHTML = '<p class="console-log error"><i class="fa-solid fa-triangle-exclamation"></i> Error connecting to GitHub repository.</p>';
    }
}

function renderFileList(files) {
    const fileContainer = document.getElementById('githubFileList');
    if (!fileContainer) return;
    
    if (files.length === 0) {
        fileContainer.innerHTML = '<p class="console-log" style="text-align: center; color: #888;">Vault is currently empty. Upload files above.</p>';
        return;
    }

    let html = '';
    files.forEach((file) => {
        const icon = getFileIcon(file.name);
        html += `
            <div class="file-item">
                <span class="file-item-name" style="color: #e0e0e0;">
                    <i class="fa-solid ${icon}"></i> ${file.name}
                </span>
                <div style="display: flex; gap: 15px; font-size: 0.85rem; font-family: 'Outfit', sans-serif; align-items: center;">
                    <button onclick="openFilePreview('${file.name.replace(/'/g, "\'")}', '${file.url}')" style="background: none; border: none; color: var(--primary-color); cursor: pointer; display: flex; align-items: center; gap: 4px;" title="Preview">
                        <i class="fa-solid fa-eye"></i> View
                    </button>
                    <a href="${file.url}" target="_blank" download="${file.name}" style="color: #27c93f; text-decoration: none; display: flex; align-items: center; gap: 4px;" title="Download">
                        <i class="fa-solid fa-download"></i> Download
                    </a>
                    <button onclick="deleteRepoFile('${file.name.replace(/'/g, "\'")}', '${file.sha || ''}')" style="background: none; border: none; color: #ff5f56; cursor: pointer; display: flex; align-items: center; gap: 4px;" title="Delete">
                        <i class="fa-solid fa-trash-can"></i> Delete
                    </button>
                </div>
            </div>
        `;
    });
    fileContainer.innerHTML = html;
}

function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    pendingFileToUpload = file;
    event.target.value = '';

    const savedToken = localStorage.getItem('github_vault_token');
    if (!savedToken) {
        document.getElementById('githubTokenModal').style.display = 'flex';
        document.getElementById('githubTokenInput').value = '';
        setTimeout(() => document.getElementById('githubTokenInput').focus(), 100);
    } else {
        commitFileToGitHub(pendingFileToUpload, savedToken);
    }
}

function closeTokenModal() {
    const modal = document.getElementById('githubTokenModal');
    if (modal) modal.style.display = 'none';
    pendingFileToUpload = null;
}

function saveGitHubTokenAndUpload() {
    const token = document.getElementById('githubTokenInput').value.trim();
    if (!token) {
        showGlassToast('[ERROR] Please enter a valid GitHub Token.');
        return;
    }
    localStorage.setItem('github_vault_token', token);
    closeTokenModal();

    if (pendingFileToUpload) {
        commitFileToGitHub(pendingFileToUpload, token);
    }
}

async function commitFileToGitHub(file, token) {
    const owner = 'Srinuas';
    const repo = 'files';
    const branch = 'main';
    const path = file.name;

    showGlassToast(`[GIT] Pushing '${file.name}' to GitHub repository...`);

    const reader = new FileReader();
    reader.onload = async function(e) {
        const base64Content = e.target.result.split(',')[1];

        try {
            let fileSha = null;
            const checkRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (checkRes.ok) {
                const fileData = await checkRes.json();
                fileSha = fileData.sha;
            }

            const bodyData = {
                message: `feat: upload ${path} via secure vault console`,
                content: base64Content,
                branch: branch
            };
            if (fileSha) bodyData.sha = fileSha;

            const putRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Accept': 'application/vnd.github+json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(bodyData)
            });

            if (!putRes.ok) {
                const errJson = await putRes.json();
                throw new Error(errJson.message || 'GitHub API commit failed');
            }

            showGlassToast(`[SUCCESS] File '${file.name}' committed directly to GitHub public repository!`);
            pendingFileToUpload = null;
            loadFilesRepositoryTree();

        } catch (err) {
            console.error('GitHub Commit Error:', err);
            showGlassToast(`[ERROR] Commit failed: ${err.message}. Check token permissions.`);
        }
    };
    reader.readAsDataURL(file);
}

async function deleteRepoFile(fileName, fileSha) {
    const token = localStorage.getItem('github_vault_token');
    if (!token) {
        document.getElementById('githubTokenModal').style.display = 'flex';
        showGlassToast('[AUTH REQUIRED] Enter GitHub Token to authorize deletion.');
        return;
    }

    if (!confirm(`Permanently delete '${fileName}' from the public GitHub repository?`)) return;

    const owner = 'Srinuas';
    const repo = 'files';
    const branch = 'main';

    showGlassToast(`[GIT] Removing '${fileName}' from GitHub...`);

    try {
        let sha = fileSha;
        if (!sha || sha === 'undefined') {
            const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${fileName}`);
            if (res.ok) {
                const data = await res.json();
                sha = data.sha;
            }
        }

        const delRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${fileName}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/vnd.github+json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: `chore: delete ${fileName} via secure vault`,
                sha: sha,
                branch: branch
            })
        });

        if (!delRes.ok) throw new Error('GitHub delete operation failed');

        showGlassToast(`[SUCCESS] File '${fileName}' deleted from GitHub.`);
        loadFilesRepositoryTree();

    } catch (err) {
        console.error('Delete Error:', err);
        showGlassToast(`[ERROR] Failed to delete file: ${err.message}`);
    }
}

function showGlassToast(message) {
    const container = document.getElementById('vaultToastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'glass-toast-notification';
    toast.innerHTML = `<i class="fa-solid fa-circle-info" style="color: var(--primary-color); margin-right: 8px;"></i> ${message}`;
    
    container.innerHTML = '';
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 400);
    }, 5000);
}

function getFileIcon(filename) {
    const ext = filename.split('.').pop().toLowerCase();
    switch(ext) {
        case 'pdf': return 'fa-file-pdf';
        case 'jpg': case 'jpeg': case 'png': case 'gif': case 'webp': return 'fa-file-image';
        case 'html': case 'css': case 'js': case 'py': case 'json': case 'yml': case 'yaml': return 'fa-file-code';
        case 'md': return 'fa-file-lines';
        default: return 'fa-file';
    }
}

async function openFilePreview(fileName, fileUrl) {
    const modal = document.getElementById('filePreviewModal');
    const contentDiv = document.getElementById('filePreviewContent');
    const downloadBtn = document.getElementById('previewDownloadBtn');
    const titleSpan = document.getElementById('previewFileName');

    if (!modal) return;
    titleSpan.innerText = fileName;
    downloadBtn.href = fileUrl;
    downloadBtn.setAttribute('download', fileName);
    contentDiv.innerHTML = '<i class="fa-solid fa-spinner fa-spin" style="font-size: 2rem; color: var(--primary-color);"></i><p style="margin-top: 10px; color: #aaa;">Loading preview...</p>';
    modal.style.display = 'flex';

    const ext = fileName.split('.').pop().toLowerCase();

    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext) || fileUrl.startsWith('data:image')) {
        contentDiv.innerHTML = `<img src="${fileUrl}" style="max-width: 100%; max-height: 70vh; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5);">`;
    } else if (ext === 'pdf') {
        contentDiv.innerHTML = `<iframe src="${fileUrl}" style="width: 100%; height: 70vh; border: none; border-radius: 8px; background: #fff;"></iframe>`;
    } else {
        try {
            const response = await fetch(fileUrl);
            const text = await response.text();
            contentDiv.innerHTML = `
                <pre style="text-align: left; background: #05050a; padding: 15px; border-radius: 8px; overflow-x: auto; max-height: 70vh; border: 1px solid rgba(255,255,255,0.1); color: #ccc; font-family: 'Fira Code', monospace; font-size: 0.85rem;"><code>${text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</code></pre>
            `;
        } catch (err) {
            contentDiv.innerHTML = `<p style="color: #ff5f56;"><i class="fa-solid fa-triangle-exclamation"></i> Preview not available. Please use download button.</p>`;
        }
    }
}

function closeFilePreview() {
    const modal = document.getElementById('filePreviewModal');
    if (modal) modal.style.display = 'none';
    const contentDiv = document.getElementById('filePreviewContent');
    if (contentDiv) contentDiv.innerHTML = '';
}
